<?php
/*
 * @copyright Copyright (c) 2024 AltumCode (https://altumcode.com/)
 *
 * This software is exclusively sold through https://altumcode.com/ by the AltumCode author.
 * Downloading this product from any other sources and running it without a proper license is illegal,
 *  except the official ones linked from https://altumcode.com/.
 */

const PRODUCT_NAME = '66biolinks';
const PRODUCT_KEY = '66biolinks';
const PRODUCT_URL = 'https://altumco.de/66biolinks';
const PRODUCT_DOCUMENTATION_URL = 'https://altumco.de/66biolinks-docs';
const PRODUCT_CHANGELOG_URL = 'https://altumco.de/66biolinks-changelog';

